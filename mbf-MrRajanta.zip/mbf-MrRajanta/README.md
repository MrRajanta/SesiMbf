# Multi Brute Force

cookies method with python2 version
![MBF](https://github.com/MrRajanta/mbf/blob/master/screenshot/mbf.jpg)

## Installation
```
pkg install python2
pip2 install requests bs4
```

## Run script
```
cd mbf
python2 run.py
```

## Contact
[What'sApp](+62 821-4018-4446)
